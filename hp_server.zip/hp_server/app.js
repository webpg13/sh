// 1.引入express模块，打好服务器基底
const express = require("express");
const bodyParser = require("body-parser");

// 引入路由模块
const Product1 = require("./routes/product1");
const Product2 = require("./routes/product2");
const User = require("./routes/user");
const Details = require("./routes/details");
const Youhui = require("./routes/youhui");
const shopcar = require("./routes/shoppingcar");
const zhuanti = require("./routes/zhuanti");


// 2.创建服务器
const server =express();

// 3.指定静态资源目录
server.use(express.static("public"));

// 4.处理跨域请求
const cors = require("cors");
//调用中间件,设置可以跨域访问的域名
server.use(cors({
  origin:["http://127.0.0.1:8080","http://localhost:8080"],
  credentials:true //可接受服务端cookie
}));

// 使用body-parser中间件，处理post请求的查询数据
// server.use(bodyParser.urlencoded({extended:false}));
server.use(bodyParser.json());

// 5.添加session功能
const session = require("express-session");
server.use(session({
  secret:"128位字符串",
  resave:true,
  saveUninitialized:true
}))

// 6.绑定监听端口
server.listen(3000);

// 7.挂载路由路径
server.use('/product',Product1);
server.use('/product',Product2);
server.use('/product',Details);
server.use(shopcar);
server.use(Youhui);
server.use(zhuanti);
server.use('/user',User);
