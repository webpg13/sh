// 创建mysql连接池
const mysql = require("mysql");
var pool = mysql.createPool({
  host:'w.rdc.sae.sina.com.cn',
  port:'3306',
  user:'wzj0nn2wx2',
  password:'hjhhh3ymiwm41kyhy4xzzmkhym2yhil5xw3wy52l',
  database:'app_mhpj',
  connectionLimit:15
});
// 把创建好的连接池导出
module.exports = pool;
