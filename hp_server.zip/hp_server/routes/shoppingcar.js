// 引入express第三方模块，用于创建路由
const express = require('express');
const router = express.Router();
// 引入连接池
const pool = require("../pool.js");

router.get("/shoppingcar",(req,res)=>{
    console.log(req.query);
    var size = req.query.size;
    var p_name = req.query.p_name;
    var price = req.query.price;
    var sql = "INSERT INTO shoppingcar SET ?"
    pool.query(sql,[req.query],(err,result)=>{
        if(err) throw err;
        if(result.affectedRows>0){
            res.send(result);
        }
    })
})

// 查询用户对于的购物车商品
router.get("/getcardata",(req,res)=>{
    var uid = req.query.uid;
    console.log(uid);
    var sql = "SELECT * FROM shoppingcar WHERE uid=?";
    pool.query(sql,[uid],(err,result)=>{
        if(err) throw err;
        if(result.length>0){
            res.send({code:1,msg:"请求成功",data:result});
        }else{
            res.send({code:0,msg:"请求错误"});
            console.log(result);
        }
    })
})

// 删除用户选中的商品
router.get("/delcardata",(req,res)=>{
    var ids = req.query.id;
    var sql = `DELETE FROM shoppingcar  WHERE id IN(${ids})`;
    pool.query(sql,[ids],(err,result)=>{
        if(err) throw err;
        if(result.affectedRows>0){
            res.send({code:1,msg:"操作成功",data:result});
        }else{
            res.send({code:0,msg:"操作错误"});
            console.log(result);
        }
    })
})



// 导出路由
module.exports = router;