const express = require('express');
const router = express.Router();
const pool = require("../pool");

// 加载一部分商品
router.get("/someProduct",(req,res)=>{
    // pno 页码; ps 页大小
    var pno = req.query.pno;
    var ps = req.query.pageSize; 
    // 2.默认值
    /* if(!pno){pno=1}
    if(!ps){ps=5} */
    // var sql = "SELECT * FROM product2";
    var sql = "SELECT * FROM product2 LIMIT ?,?";
    // offset 起始行数    起始行数 = (页码-1) * 页大小
    var offset = (pno-1)*ps;
    ps = parseInt(ps); 
    pool.query(sql,[offset,ps],(err,result)=>{
        if(err) throw err;
        if(result.length>0){
            res.send({code:1,msg:"请求成功",data:result});
        }
    })
})

// 分类加载商品
router.get("/product2",(req,res)=>{
    // pno 页码; ps 页大小
    /* var pno = req.query.pno;
    var ps = req.query.pageSize; */
    // 2.默认值
    /* if(!pno){pno=1}
    if(!ps){ps=5} */
    var sql = "SELECT * FROM product2";
    // var sql = "SELECT * FROM product2 LIMIT ?,?";
    // offset 起始行数    起始行数 = (页码-1) * 页大小
    /* var offset = (pno-1)*ps;
    ps = parseInt(ps); */
    pool.query(sql,[],(err,result)=>{
        if(err) throw err;
        if(result.length>0){
            res.send({code:1,msg:"请求成功",data:result});
        }
    })
})



module.exports = router;