// 引入express第三方模块，用于创建路由
const express = require('express');
const router = express.Router();
// 引入连接池
const pool = require("../pool.js");


// 查询一号区域的商品
router.get("/product1",(req,res)=>{
  // var pid = req.query.pid;
  var sql = "SELECT * FROM product1";
  pool.query(sql,[],(err,result)=>{
    if(err) throw err;
    if(result.length>0){
      res.send({code:1,data:result});
    }
  })
  // res.send("<h1>123</h1>");
})




// 导出路由
module.exports = router;