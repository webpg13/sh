//引入第三方模块
const express = require('express');
// 创建路由
const router = express.Router();
// 引入连接池
const pool = require("../pool");

// 用户登录路由
router.post("/login",(req,res)=>{
    var phone = req.body.uname;
    var upwd = req.body.upwd;
    console.log(phone,upwd);
    var sql = `SELECT * FROM hp_user WHERE phone=? AND upwd=md5(?)`;
    pool.query(sql,[phone,upwd],(err,result)=>{
        if(err) throw err;
        if(result.length>0){
            res.send({code:200,msg:"验证成功",data:result});
        }else{
            res.send({code:400,msg:"验证失败"});
        }
    })
})

// 用户注册路由
router.post("/register",(req,res)=>{
    // (NULL,uname=?,upwd=?,email=?,phone=?,user_name=?)
    console.log(req.body);
    var uname = req.body.uname;
    var upwd = req.body.upwd;
    var email = req.body.email;
    var phone = req.body.phone;
    var user_name = req.body.username;
    var gender = req.body.gender;
    var sql = `INSERT INTO hp_user SET uname=?,upwd=md5(?),email=?,phone=?,username=?,gender=?`;
    pool.query(sql,[uname,upwd,email,phone,user_name,gender],(err,result)=>{
        if(err) throw err;      
        if(result.affectedRow>0){
            res.send({code:0,msg:"注册成功"})
        }else{
            res.send({code:1,msg:"注册失败"})
        }
    })
})

// 查询用户名路由
router.get("/uname",(req,res)=>{
    var uname = req.query.uname;
    var sql = "SELECT * FROM hp_user WHERE uname=?";
    pool.query(sql,uname,(err,result)=>{
        if(err) throw err;
        if(result.length>0){
            res.send({code:1,msg:"用户名存在"});
        }else{
            res.send({code:0,msg:"用户名未注册"});
        }
    })
})

module.exports = router;