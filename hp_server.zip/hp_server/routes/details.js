// 引入express第三方模块，用于创建路由
const express = require('express');
const router = express.Router();
// 引入连接池
const pool = require("../pool.js");


router.get("/detailsText",(req,res)=>{
    var pd_id = req.query.id;
    var sql = "SELECT * FROM product_detail WHERE pid=?";
    pool.query(sql,[pd_id],(err,result)=>{
        if(err) throw err;
        if(result.length>0){
            res.send({code:1,msg:"查询成功",data:result})
        }else{
            res.send({code:0,msg:"查询失败"})
        }
    })
})


router.get("/detailsImg",(req,res)=>{
    var pd_id = req.query.id;
    var sql = "SELECT * FROM pd_imgs WHERE pd_id=?";
    pool.query(sql,[pd_id],(err,result)=>{
        if(err) throw err;
        if(result.length>0){
            res.send({code:1,msg:"查询成功",data:result})
        }else{
            res.send({code:0,msg:"查询失败"})
        }
    })
})


// 导出路由
module.exports = router;