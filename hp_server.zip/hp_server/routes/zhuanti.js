// 引入express第三方模块，用于创建路由
const express = require('express');
const router = express.Router();
// 引入连接池
const pool = require("../pool.js");

router.get("/getDatas",(req,res)=>{
    var id = req.query.id;
    console.log(id);
    var sql = "SELECT * FROM zhuanti WHERE id=?";
    pool.query(sql,[id],(err,result)=>{
        if(err) throw err;
        if(result.length>0){
            res.send({code:1,msg:"请求成功",data:result});
        }else{
            res.send({code:0,msg:"请求错误"});
            console.log(result);
        }
    })
})

module.exports=router;