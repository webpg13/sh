SET NAMES UTFS UTF8;
DROP DATABASE IF EXISTS hp;
CREATE DATABASE hp CHARSET=UTF8;
USE hp;

/**用户信息**/
CREATE TABLE hp_user(
  uid INT PRIMARY KEY AUTO_INCREMENT,
  uname VARCHAR(32),
  upwd VARCHAR(32),
  email VARCHAR(64),
  phone VARCHAR(16),
  avatar VARCHAR(128),        #头像图片路径
  user_name VARCHAR(32),      #用户名，如王小明
  gender INT                  #性别  0-女  1-男
)

INSERT INTO hp_user VALUES
(NULL,'cmh','123456','mh_19970712@163.com','15207683344','','陈沐怀','1'),

/**首页商品信息**/

/**商品信息表1**/
CREATE TABLE product1(
  pid INT  PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(32),
  subtitle VARCHAR(32),
  img VARCHAR(128)
);

/**插入数据**/
INSERT INTO product1 VALUES
(NULL,'篮球','纯白系列秒杀','lanqiu.jpg'),
(NULL,'跑步','女神节秒杀','paobu.jpg'),
(NULL,'健身','步瑞特装备秒杀','jianshen.jpg'),
(NULL,'足球','其实是在吹总裁','zuqiu.png'),
(NULL,'潮流','78元短袖秒杀','chaoliu.jpg'),
(NULL,'数码','电子驱蚊手环','shuma.jpg'),
(NULL,'健身','步瑞特装备秒杀','jianshen2.jpg'),
(NULL,'健身','步瑞特装备秒杀','jianshen3.jpg'),
(NULL,'健身','步瑞特装备秒杀','jianshen4.jpg'),
(NULL,'健身','步瑞特装备秒杀','jianshen5.jpg'),
(NULL,'健身','步瑞特装备秒杀','jianshen6.jpg'),
(NULL,'足球','其实是在吹总裁','zuqui2.png'),
(NULL,'足球','其实是在吹总裁','zuqui3.png'),
(NULL,'足球','其实是在吹总裁','zuqui4.png'),
(NULL,'足球','其实是在吹总裁','zuqui5.png'),
(NULL,'足球','其实是在吹总裁','zuqui6.png'),
(NULL,'潮流','78元短袖秒杀','chaoliu2.jpg'),
(NULL,'潮流','78元短袖秒杀','chaoliu3.jpg'),
(NULL,'潮流','78元短袖秒杀','chaoliu4.jpg'),
(NULL,'数码','电子驱蚊手环','shuma2.jpg'),
(NULL,'数码','电子驱蚊手环','shuma3.jpg'),
(NULL,'数码','电子驱蚊手环','shuma4.jpg'),
(NULL,"今日优惠","EQT 5折好价","shoes1.jpg"),
(NULL,"限时团购","春节不打烊","shoes2.png"),
(NULL,"一键海淘","卡西欧黑金249元","watch.jpg"),
(NULL,"skullcandy骷髅头耳机","券后低至89元起","img1.jpg"),
(NULL,"5折上新，95分专属抢购","低价折扣超值精选","img2.jpg"),
(NULL,"怎么穿，显高且有范","170+穿搭指南","img3.jpg"),
(NULL,"数码测评","全面解析热门数码产品","img4.jpg"),
(NULL,"实战性价比之选","球星支线","img5.jpg"),
(NULL,"花鸟市场行","今天穿这样","img6.jpg"),
(NULL,"虎扑优选精英篮球袜","低至6.9元","img7.jpg"),
(NULL,"装备微讯","2分钟懂你想要","img8.jpg"),
(NULL,"热门资讯","最新最热门的数码资讯","img9.jpg"),
(NULL,"独家折扣专场","买到就是赚到！","img10.jpg"),
(NULL,"好物推荐","为您推荐潮酷好物","img11.jpg"),
(NULL,"跑步评测室","最炫酷的跑步装备评测","img12.jpg"),
(NULL,"潮流折扣日Vol.53","别再错过专属优惠了","img13.jpg"),
(NULL,"1000块包全身","不说虚话","img14.jpg"),
(NULL,"潮流圈的编辑们","Ta说","img15.png"),
(NULL,"考虑一下荧光绿","要想生活过的去","img16.jpg"),
(NULL,"#什么跑鞋值得买#","晒晒你最爱的跑鞋","img17.jpg"),
(NULL,"5折上新，95分专属抢购","低价折扣超值精选","img18.jpg"),
(NULL,"应季机能风","酷战雨雪","img19.jpg");

/**商品信息表2**/
CREATE TABLE product2(
  pid INT  PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(32),
  subtitle VARCHAR(32),
  price VARCHAR(32),
  img VARCHAR(128),
  special INT
);

/**向商品信息表2数据**/
INSERT INTO product2 VALUES
(NULL,"Air Jordan 11","鞋面在光线下呈现一丝墨绿","淘宝¥790","AJ11.jpg","0","篮球"),
(NULL,"Nike Kyrie 4","纪念总决赛41分超神表现","淘宝¥579","Kyire4.jpg","0","篮球"),
(NULL,"李宁 曜影 ARHM119 黑白","李宁云科技减震","淘宝¥308","ARHM119.jpg","1","跑步"),
(NULL,"Air Jordan 4","质感出众整体风格极为讨好","淘宝¥2288","AJ4.jpg","0","篮球"),
(NULL,"Nike Paul George PG 2","PG 2雷霆复活节彩蛋","淘宝¥799","PG2_fhj.jpg","0","篮球"),
(NULL,"UO 翻领polo衫 U19221T605","潮流有型翻领polo衫","天猫商城","UOshirt.jpg","1","潮流"),
(NULL,"美特斯邦威 运动休闲足球T恤 707003","潮流有型运动休闲足球t恤","天猫商城","sportTs(1).png","1","潮流"),
(NULL,"UO 抽绳收脚裤 E19233X110","潮流有型抽绳收脚裤","天猫商城","UOkuzi.jpg","1","潮流"),
(NULL,"Reebok 锐步 运动训练短袖搏击T恤","吸湿排汗速干透气","天猫商城","manTshirt.png","1","潮流"),
(NULL,"Reebok锐步官方 运动健身  男子连帽夹克","休闲时尚 基础简约","天猫商城","manJack.jpg","1","潮流"),
(NULL,"Nike Epic React Flyknit",'纯白色加身，魅力难以阻挡。"',"淘宝¥390","NikeEpicReact Flyknit.png","1","跑步"),
(NULL,"adidas 运动短袖T恤 DN7389","个性印花，玩转时尚，酷感十足","天猫¥124","adTX.png","1","健身"),
(NULL,"热款丨Nike 男子休闲运动短裤 836278","宽松短裤，酷感中带着随性，适合各种腿型","天猫¥169","NIKEdk.png","0","健身"),
(NULL,"Landcase 暗黑系列 大容量旅游运动背包 Z-301","大容量双肩包，设计师打造用途时尚背包，容量随意切换","天猫¥108","Landcase.jpg","0","健身"),
(NULL,"ASICS亚瑟士 女印花紧身长裤 135264","中腰裤头设计，刚刚好裹住小肚子，又能加强裤子的承托力，提升臀...","天猫¥199","womankz.png","0","健身"),
(NULL,"Under Armour 安德玛运动长袖T恤 1328496","Tech 运动训练长袖T恤 轻薄通透的布料 给人以舒适的运动体验","天猫¥249","mancx.jpg","0","健身"),

(NULL,"Nike Air Max Sequent 3","黑武士降临，纯黑外观打造。","淘宝¥204","MaxSequent3.png","0","跑步"),
(NULL,"准者 长袖训练紧身衣 Z117310702","准者秋冬新款紧身压缩衣紧身外套男子篮球运动训练休闲开衫上衣","天猫¥62","zhunzhejsy.jpg","0","健身"),
(NULL,"Under Armour 印花紧身裤 1320323","女子运动长裤，运动气息十足的印花设计","天猫¥299","Under Armour.jpg","0","健身"),
(NULL,"Puma/彪马 Deck 双肩包 074706","科学布局，设计周到，纯色的设计，彰显时尚，让你轻松应对多变环...","天猫¥219","Deckbag.png","1","健身"),
(NULL,"Air Jordan 1","全黑造型低调中不缺乏亮点","淘宝¥604","AJ1.jpg","0","潮流"),
(NULL,"Vans Old Skool","选用黑蓝的撞色搭配，带来更硬朗的街头风潮","淘宝¥450","VansOldSkool.jpg","1","潮流"),
(NULL,"","","","","0",""),
(NULL,"","","","","0",""),


(NULL,"","","","","0","");





-- 购物车表
CREATE TABLE shoppingcar(
  pid INT PRIMARY KEY AUTO_INCREMENT,
  size VARCHAR(32),
  p_name VARCHAR(32),
  p_count VARCHAR(32)
)



/**优惠面板的数据**/
CREATE TABLE youhuiData(
  pid INT  PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(32),
  price VARCHAR(32),
  subtitle VARCHAR(32),
  img VARCHAR(128),
  special INT,
  type VARCHAR(32)
);

/**向商品信息表2数据**/
INSERT INTO youhuiData VALUES
(NULL,"安踏 Flashfoam闪能高弹缓震跑鞋 11845588  黑红","到手价289","天猫商城","Flashfoam.jpg","1","跑步"),
(NULL,"Nike Air Max Plus  红黄鸳鸯","实付到手1199元","nike官网","NikeAirMaxPlus.jpg","1","跑步"),
(NULL,"Nike Shox R4 Neymar 黄黑红","实付到手1199元","nike官网","NikeShoxR4Neymar.jpg","1","跑步"),
(NULL,"Nike Air Foamposite One Floral 花卉","实付到手1749元","nike官网","NikeAirFoampositeOneFloral.png","1","篮球"),
(NULL,"Nike Classic Cortez Forest Gump 白蓝红","实付到手699元","nike官网","NikeClassicCortezForestGump.png","1","跑步"),
(NULL,"","","","","1",""),
(NULL,"","","","","1",""),