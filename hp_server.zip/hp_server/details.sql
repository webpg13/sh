-- 商品详情表
CREATE TABLE product_detail(
  pd_id INT PRIMARY KEY AUTO_INCREMENT,
  pid INT,
  pd_title VARCHAR(32),
  pd_subtitle VARCHAR(255),
  pd_kb INT,
  pd_cp INT,
  pd_price DECIMAL(10,2)
)

-- 向商品详情表插入数据
INSERT INTO product_detail VALUES
(NULL,"Air Jordan 11","Air Jordan 11于1995年11月推出，是乔丹本人最为喜爱的一款，见证了乔丹从...",4313,224,1799.00),
(NULL,"Nike Kyrie 4","Kyrie Irving的第四代签名鞋Kyrie 4于2017年12月5日正式亮相，由新...",4236,64,698.00),
(NULL,"Air Jordan 4","Air Jordan 4在1989年上市，设计师Tinker Hatfield首次提出后...",1938,260,2288.00),
(NULL,"Nike Paul George PG 2","北京时间2018年1月21日，保罗•乔治（Paul George）在克利夫兰首次发布他的...",2194,22,799.00),



-- 商品详情图片表
CREATE TABLE pd_imgs(
  img_id INT PRIMARY KEY AUTO_INCREMENT,
  pd_Id INT,
  img1 VARCHAR(32),
  img2 VARCHAR(32),
  img3 VARCHAR(32),
  img4 VARCHAR(32),
  img5 VARCHAR(32),
  img6 VARCHAR(32),
  img7 VARCHAR(32),
  img8 VARCHAR(32),
  img9 VARCHAR(32),
  img10 VARCHAR(32)
)

INSERT INTO pd_imgs VALUES
(NULL,1,"AJ11/AJ11(1).jpg","AJ11/AJ11(2).jpg","AJ11/AJ11(3).jpg","AJ11/AJ11(4).jpg","AJ11/AJ11(5).png","AJ11/AJ11(1)-other.jpg","AJ11/AJ11(2)-other.jpg","AJ11/AJ11(3)-other.jpg","AJ11/AJ11(4)-other.jpg","AJ11/AJ11(5)-other.jpg"),
(NULL,2,"Kyire4/Kyire4(1).png","Kyire4/Kyire4(2).jpg","Kyire4/Kyire4(3).png","Kyire4/Kyire4(4).jpg","Kyire4/Kyire4(5).png","Kyire4/Kyire4(1)-other.jpg","Kyire4/Kyire4(2)-other.jpg","Kyire4/Kyire4(3)-other.jpg","Kyire4/Kyire4(4)-other.jpg","Kyire4/Kyire4(5)-other.jpg"),
(NULL,4,"AJ4/AJ4(1).png","AJ4/AJ4(2).png","AJ4/AJ4(3).png","AJ4/AJ4(4).jpg","AJ4/AJ4(5).png","AJ4/AJ4(1)-other.jpg","AJ4/AJ4(2)-other.jpg","AJ4/AJ4(3)-other.jpg","AJ4/AJ4(4)-other.png","AJ4/AJ4(5)-other.jpg"),
(NULL,5,"PG2_FHJ/pg2_fhj(1).jpg","PG2_FHJ/pg2_fhj(2).jpg","PG2_FHJ/pg2_fhj(3).png","PG2_FHJ/pg2_fhj(4).jpg","PG2_FHJ/pg2_fhj(5).jpg","PG2_FHJ/pg2_fhj(1)-other.jpg","PG2_FHJ/pg2_fhj(2)-other.jpg","PG2_FHJ/pg2_fhj(3)-other.jpg","PG2_FHJ/pg2_fhj(4)-other.jpg","PG2_FHJ/pg2_fhj(5)-other.png"),


